﻿namespace StaffApi.Models
{
    public class Staff
    {
        public string Id { get; set; } 
        public string Name { get; set; }
        public string[] subject { get; set; }
        public int[] std {  get; set; }

    }
}

﻿namespace Assignment_10.Model
{
    public class Product
    {
        public int Product_Id {  get; set; }
     public string ProductName {  get; set; }
    public string Category { get; set; }
     public int  Price { get; set; }
     public int Stock { get; set; }

    }
}
